# Meu Portifólio

## Next Projects

Sempre deixar com essa mesma organizaçAo de pastas, porque se vocÊ tiver que refazer a organizaçao depois é muito cahto. Deix bem organizado no começo que nao vai perder tmepo com isso.

English Version fica pro final.

Quick
+ Column no nav

## Documentation Fron End

Photo by James Douglas on Unsplash

Royal Blue
https://www.canva.com/colors/color-meanings/royal-blue/
Pallete
https://www.canva.com/colors/color-palettes/carnival-of-feathers/
Freesia (Amarelo)
#E2B327

Blue Grotto (Azul mais claro)
#4693B8

Royal Blue (AzuL Real)
#0B1F65

Ivory (Marfim)
#E1D9D1

**FavIcon**

https://favicon.io/favicon-generator/

**SVG : Hero Icons**
https://heroicons.com/

https://freeicons.io/filter/popular/all/link

**Language PopHover**
+ Bandeiras: https://www.countryflags.io/
+ Ajuste de opacity: https://www4.lunapic.com/editor/?action=alpha-transparency
+ language selector youtube: https://www.youtube.com/watch?v=ByraB2uMAiM&ab_channel=BlueBits

**Time-line**
+ aLgum lugar de web-theme-index

**Next**
+ Number 8 - Strane
+  - Hover on image
+  - Up in cellphone

Hamburgues
7 - mdcard-orange-many-color

**NEW TODO**
+ OG [X]
+ Schema Colors (like Tailwind Use, :root and serve in other css files)
  - Saturaçâo [x]
+ Seçâo de preço
+ Loader [X]
+ Melhorar título (maior/colorido) [x]
+ Por mais cores (background/svg-elementor) [x]
+ Deletar Imagesn de projetos nâo usados e arquivos nao usados [x]
+ Mobile / MultiTelas [x]
+ EN PAGE [last]


## Erros do site checekr pro
