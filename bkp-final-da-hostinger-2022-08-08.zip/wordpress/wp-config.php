<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u790917553_FgUwG' );

/** MySQL database username */
define( 'DB_USER', 'u790917553_4pNtL' );

/** MySQL database password */
define( 'DB_PASSWORD', '3gtz5PVQfQ' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'w=QP(wO5i`^zN<;%QtJ,#`[g8p+zoi@<C:?uRErH`.zpU4k@^OFsv_JC/26UOuX_' );
define( 'SECURE_AUTH_KEY',   'C;-`K:c{sIgod;1K@3`*CX=Q8(0XUF*bP:4OSei+?o]l#Xs>Usk6@s3xM/kjTzvi' );
define( 'LOGGED_IN_KEY',     'fbDB5wz9D^wp_^4g`XdBS$>[*-w$E@nleY2{U*TNjr&u+Vam^tjOC,5>Zpw`m32$' );
define( 'NONCE_KEY',         '.u2-^%/I6-QJ9}J5+>(z8xYZel:_a.Ju-4pZzos?n#[K<$EioT~Y7G1A0<v4SJwp' );
define( 'AUTH_SALT',         'gKF&f6tbuSTg$qO8n#`@z0X;YQ`t>!xlzD]UY%?*z88-&W})#>Iee;q23V82(nfO' );
define( 'SECURE_AUTH_SALT',  'Bj0i$g6RI6K|@%MF6osnB r]QtEx&XT8.vqvWSOmFMd@]yzlbK|pwarxet1c#+x?' );
define( 'LOGGED_IN_SALT',    'Fa$;$gKk)>y(&[G!^*P8&DDQ89?`$>E@PpIiG3$o$ugs )]xF2abP_P:x1|tW)el' );
define( 'NONCE_SALT',        '=UOK5,OKZXbi/6l]Br:gX5s6w?hB>o&J,@{men_m0mX2OxH[z}}dCyp%f89&Fno#' );
define( 'WP_CACHE_KEY_SALT', 'u( xiy0Es-PsAMU[BpN;|CvK3q4i/IW7jf*r!Kb*D>J_H#0T+C-0DKc{ )xZMuYK' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
