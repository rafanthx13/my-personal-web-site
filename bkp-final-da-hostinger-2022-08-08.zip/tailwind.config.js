module.exports = {
  purge:{
    enabled: true,
    content: [
      './pages/**/*.html',
      './index.html',
    ]
  },
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
