# Doc Front End

## Documentation Fron End

Photo by James Douglas on Unsplash

Royal Blue
https://www.canva.com/colors/color-meanings/royal-blue/
Pallete
https://www.canva.com/colors/color-palettes/carnival-of-feathers/
Freesia (Amarelo)
#E2B327

Blue Grotto (Azul mais claro)
#4693B8

Royal Blue (AzuL Real)
#0B1F65

Ivory (Marfim)
#E1D9D1

**FavIcon**

https://favicon.io/favicon-generator/

**SVG : Hero Icons**
https://heroicons.com/

https://freeicons.io/filter/popular/all/link

**Language PopHover**
+ Bandeiras: https://www.countryflags.io/
+ Ajuste de opacity: https://www4.lunapic.com/editor/?action=alpha-transparency
+ language selector youtube: https://www.youtube.com/watch?v=ByraB2uMAiM&ab_channel=BlueBits

**Time-line**
+ algum lugar de web-theme-index

**Next**
+ Number 8 - Strane
+  - Hover on image
+  - Up in cellphone

Hamburgues
7 - mdcard-orange-many-color

## Dicas de otimização

+ Imagens jpg devem ser coprimidas e convertidas para webp

1. Toda imagem deve ter width e heigh na sua tag html, mesmo que seja modificada com css
2. toda imagem deve ter alt
3. jsquey usesempre o ultimo mais seguro

